# Mybtatis整合Spring的使用方式

## 1 依赖jar包

### 1.1 mybatis

Mybatis的原生的jar包

```xml
<dependency>
    <groupId>org.mybatis</groupId>
    <artifactId>mybatis</artifactId>
</dependency>
```

### 1.2 spring

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-jdbc</artifactId>
</dependency>
```

Spring事务管理jar包

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-tx</artifactId>
</dependency>
```

数据库操作的jar包

```xml
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
</dependency>
```

数据源创建的jar包

```xml
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid</artifactId>
</dependency>
```



## 2 使用方式

```xml
<bean id="jdbcTemplate" class="org.springframework.jdbc.core.jdbcTemplate">
    <property name="dataSource" ref="dataSource"/>
</bean>

<bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource" init-method="init" destroy-method="close">
        <property name="url" value="${jdbc_url}" />
        <property name="username" value="${jdbc_user}" />
        <property name="password" value="${jdbc_password}" />
        <property name="filters" value="stat" />
        <property name="maxActive" value="20" />
        <property name="initialSize" value="1" />
        <property name="maxWait" value="60000" />
        <property name="minIdle" value="1" />
        <property name="timeBetweenEvictionRunsMillis" value="60000" />
        <property name="minEvictableIdleTimeMillis" value="300000" />
        <property name="testWhileIdle" value="true" />
        <property name="testOnBorrow" value="false" />
        <property name="testOnReturn" value="false" />
        <property name="poolPreparedStatements" value="true" />
        <property name="maxOpenPreparedStatements" value="20" />

        <property name="asyncInit" value="true" />
        <!--统计SQL执行时间，防止SQL注入的过滤器-->
        <property name="filters" value="stat,wall"/>
    </bean>
</bean>

<!--加载mybatis的配置文件-->
<bean id="sqlSessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
    <property name="dataSource" ref="dataSource"/>
    <property name="configLocation" value="classpath:mybatis-config.xml"/>
    <property name="mapperLocations">
        <array>
            <value>classpath:mybatis/*/*.xml</value>
        </array>
    </property>
</bean>

<!--配置事务管理-->
<bean name="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
    <property name="dataSource" value="dataSource"/>
</bean>

<bean id="sqlSessionTemplate" class="org.mybatis.spring.SqlSessionTemplate">
    <constructor-arg index="0" ref="sqlSessionFactory"/>
</bean>

<bean id="transactionTemplate" class="org.springframework.transaction.support.TransactionTemplate">
    <property name="transactionManager" ref="transactionManager"/>
</bean>

<!--扫描DAO接口-->
<bean id="mapperScannerConfigurer" class="org.mybatis.spring.mapper.MapperScannerConfigurer">
    <property name="basePackage" value="mappers接口路径"/>
</bean>

<!--启用事务事务管理的注解-->
<tx:annotation-driven/>

<!-- 或者使用标签 -->
<tx:advice id="txAdvice" transaction-manager="txManager" >   <!-- 仍然使用txManager作为事务管理组件 -->
    <tx:attributes>
        <!--事务管理方法列表-->
        <tx:method name="updateTitleAndBody" />   <!-- 在哪些方法上添加事务管理 -->
        <tx:method name="register" />             <!-- 这里写方法名 -->
        <tx:method name="checkLogin" />           <!-- 支持通配符 -->
        <tx:method name="listNotebook" />
        <tx:method name="getDeletedNotes" />
    </tx:attributes>
</tx:advice>
```




## 3 源码分析

### 3.1 配置解析

**org.mybatis.spring.SqlSessionFactoryBean**

![SqlSessionFactoryBean](.\SqlSessionFactoryBean.png)

SqlSessionFactoryBean存在的目的是创建Mybatis中的SqlSessionFactory对象。进而集成再mybatis-Spring中便于Spring的application context使用的一个对象。SqlSessionFactory可以通过依赖注入的方式传递给基于Mybatis的DAO。DataSourceTransactionManager或JtaTransactionManager可以与SqlSessionFactory一起用于事务界限的划分。JTA应该用于跨多个数据库的事务或使用容器管理事务（CMT）时。

官方源码解释如下：

```
FactoryBean that creates a MyBatis SqlSessionFactory. This is the usual way to set up a shared MyBatis SqlSessionFactory in a Spring application context; the SqlSessionFactory can then be passed to MyBatis-based DAOs via dependency injection. Either DataSourceTransactionManager or JtaTransactionManager can be used for transaction demarcation in combination with a SqlSessionFactory. JTA should be used for transactions which span multiple databases or when container managed transactions (CMT) are being used.
```

如类图所示，SqlSessionFactoryBean分表集成了ApplicationListener、FactoryBean和InitializingBean三个Spring接口，这三个接口的作用分别为

**InitializingBean接口**的作用是为了创建一个默认的SqlSessionFactory的Bean为系统使用。在这个初始化SqlSession的过程就是将配置文件中的所有参数传递给Mybtis，XML文件之间传递给XMLConfigBuilder解析成Mybatis的参数管理对象Configuration，之后将其他的参数直接传递给Configuration对象。

必传参数如下所示

setDataSource：设置dataSource数据源

setConifgLoction：设置mybatis-config.xml配置文件

setMapperLocations：设置mapper.xml文件位置

**FactoryBean接口**的作用是将InitializingBean创建的SqlSessionFactory默认实现类暴露给Spring容器进行管理

**ApplicationListener接口**的作用是在项目初始化完成以后，监听ContextRefreshedEvent事件且校验Myabtis的XML配置解析是否完成。但在校验还有一个failFast标签标识是否需要做校验，默认为false，不做校验。



**org.mybatis.spring.mapper.MapperScannerConfigurer**

![MapperScannerConfigurer](.\MapperScannerConfigurer.png)

setBasePackage：设置dao层文件夹路径

MapperScannerConfigurer的作用是将Mapper接口连带XML文件的SQL转变为一个Bean交给Spring容器管理，其实现的接口功能分别为

BeanDefinitionRegistryPostProcessor接口是集成了BeanFactoryPostProcessor接口，主要作用是在其实现方法postProcessBeanDefinitionRegistry中注册Bean。在此方法将registry传递给ClassPathMapperScanner对象，之后将多有参数都传递给ClassPathMapperScanner对象处理。

![ClassPathMapperScanner](.\ClassPathMapperScanner.png)



在ClassPathMapperScanner中实现了Mapper接口的注册，在真正注册时，使用的时ClassPathBeanDefinitionScanner的registerBeanDefinition方法将已经转换成BeanDefinitionHolder对象的mapper接口注册给BeanDefinitionRegistry。

这其中的MapperScannerConfigurer、ClassPathMapperScanner和ClassPathBeanDefinitionScanner之间的调用关系如下所示。

InitializingBean接口的作用是校验basePackages不能为空，因为这个参数需要传递mapper接口所在的包名，如果为空，则报错。

ApplicationContextAware接口的作用是提供ApplicationContext对象给ClassPathMapperScanner的对象。

BeanNameAware：为当前的类设置Bean名称。



**org.mybatis.spring.SqlSessionTemplate**

![SqlSessionTemplate](.\SqlSessionTemplate.png)

SqlSessionTemplate是一个Spring实现了Mybatis的sqlSession的接口，可以完成数据库的相关操作，作用是负责管理MyBatis的SqlSession，调用MyBatis的SQL方法，翻译异常。

sqlSession：定义了一系列的数据库操作的方法。官方注释为：

```
The primary Java interface for working with MyBatis. Through this interface you can execute commands, get mappers and manage transactions.
```

可以看出这个接口的作用是Mybatis提供的一个执行数据库命令，获取映射mapper以及管理事务的一个工具接口。



### 3.2 Sprting事务控制

**org.springframework.jdbc.datasource.DataSourceTransactionManager**

![DataSourceTransactionManager](.\DataSourceTransactionManager.png)

配置事务管理，需要添加需要进行Spring做事务管理的数据源，配置此对象的目的是将数据操作的事务控制交给Spring管理。

DataSourceTransactionManager是实现了Spring的PlatformTransactionManager接口，

```java
public interface PlatformTransactionManager {
    //返回当前活动的事务或创建一个新的事务。
    //参数definition描述了事务的属性，比如传播行为，隔离级别，超时等
    TransactionStatus getTransaction(TransactionDefinition definition) throws TransactionException
        
    //根据给定事务的状态提交给定事务
    void commit(TransactionStatus status) throws TransactionException;  
    
    //执行给定事务的回滚
    void rollback(TransactionStatus status) throws TransactionException;
}
```

这只是事务控制的一个框架，具体执行事务的是通过TransactionInterceptor类的invoker方法执行事务

org.springframework.transaction.interceptor.TransactionInterceptor，在这里就涉及到了Spring的事务实现方式，会在以后的章节中介绍。

ResourceTransactionManager接口集成了PlatformTransactionManager接口，并且提供了一个获取事务控制数据源的工厂方法

图中AbstractPlatformTransactionManager方法提供了一个实现Spring标准事务工作流的抽象基类，主要提供以下功能，但子类必须为事务的特定状态实现特定的模板方法（包括以下方法begin, suspend, resume, commit, rollback）：

- 判断事务是否存在。

- 使用事务的传播行为。

- 在必要的情况下挂起和撤销事务。

- 在提交时检查rollback-only标志。

- 对回滚应用适当的修改（仅限实际回滚或设置回滚）。

- 触发已注册的同步回调（如果事务同步处于活动状态）。


因此DataSourceTransactionManager类主要实现和业务相关的行为，包括

- 获取事务

```java
@Override
protected Object doGetTransaction() {
   DataSourceTransactionObject txObject = new DataSourceTransactionObject();
   txObject.setSavepointAllowed(isNestedTransactionAllowed());
   ConnectionHolder conHolder =
         (ConnectionHolder) TransactionSynchronizationManager.getResource(obtainDataSource());
   txObject.setConnectionHolder(conHolder, false);
   return txObject;
}
```



- 开启事务 - 设置事务隔离级别且忽略超时设置

```java
@Override
protected void doBegin(Object transaction, TransactionDefinition definition) {
   DataSourceTransactionObject txObject = (DataSourceTransactionObject) transaction;
   Connection con = null;

   try {
      if (!txObject.hasConnectionHolder() ||
            txObject.getConnectionHolder().isSynchronizedWithTransaction()) {
         Connection newCon = obtainDataSource().getConnection();
         if (logger.isDebugEnabled()) {
            logger.debug("Acquired Connection [" + newCon + "] for JDBC transaction");
         }
         txObject.setConnectionHolder(new ConnectionHolder(newCon), true);
      }

      txObject.getConnectionHolder().setSynchronizedWithTransaction(true);
      con = txObject.getConnectionHolder().getConnection();

      // 根据数据连接和事务属性，获取数据库连接的事务隔离级别  
      Integer previousIsolationLevel = DataSourceUtils.prepareConnectionForTransaction(con, definition);
      txObject.setPreviousIsolationLevel(previousIsolationLevel);
      txObject.setReadOnly(definition.isReadOnly());

      // 自动提交/手动提交事务判断
      if (con.getAutoCommit()) {
         txObject.setMustRestoreAutoCommit(true);
         if (logger.isDebugEnabled()) {
            logger.debug("Switching JDBC Connection [" + con + "] to manual commit");
         }
         con.setAutoCommit(false);
      }

      prepareTransactionalConnection(con, definition);
      // 激活当前数据源事务对象的事务配置
      txObject.getConnectionHolder().setTransactionActive(true);

       // 设置事务超时
      int timeout = determineTimeout(definition);
      if (timeout != TransactionDefinition.TIMEOUT_DEFAULT) {
         txObject.getConnectionHolder().setTimeoutInSeconds(timeout);
      }

      // 把当前数据库Connection和线程绑定 
      if (txObject.isNewConnectionHolder()) {
         TransactionSynchronizationManager.bindResource(obtainDataSource(), txObject.getConnectionHolder());
      }
   }

   catch (Throwable ex) {
      if (txObject.isNewConnectionHolder()) {
         DataSourceUtils.releaseConnection(con, obtainDataSource());
         txObject.setConnectionHolder(null, false);
      }
      throw new CannotCreateTransactionException("Could not open JDBC Connection for transaction", ex);
   }
}
```

- 封装事务对象

DataSourceTransactionManager类的内部类DataSourceTransactionObject是数据源事务对象



**org.springframework.transaction.support.TransactionTemplate**

![TransactionTemplate](.\TransactionTemplate.png)

做事务控制，在编程时使用TransactionTemplate对象的execute方法管理事务

TransactionTemplate是一个支持手动控制事务执行的一个方法类，调用其execute方法，实现TransactionCallback接口作为方法传入即可实现手动的事务控制。如下所示：

```java
@Override
@Nullable
public <T> T execute(TransactionCallback<T> action) throws TransactionException {
   Assert.state(this.transactionManager != null, "No PlatformTransactionManager set");

   if (this.transactionManager instanceof CallbackPreferringPlatformTransactionManager) {
      return ((CallbackPreferringPlatformTransactionManager) this.transactionManager).execute(this, action);
   }
   else {
      TransactionStatus status = this.transactionManager.getTransaction(this);
      T result;
      try {
         result = action.doInTransaction(status);
      }
      catch (RuntimeException | Error ex) {
         // Transactional code threw application exception -> rollback
         rollbackOnException(status, ex);
         throw ex;
      }
      catch (Throwable ex) {
         // Transactional code threw unexpected exception -> rollback
         rollbackOnException(status, ex);
         throw new UndeclaredThrowableException(ex, "TransactionCallback threw undeclared checked exception");
      }
      this.transactionManager.commit(status);
      return result;
   }
}
```

获取TransactionTemplate的对象，调用execute方法执行需要进行事务控制的数据库操作。TransactionTemplate可以通过回调的方式实现事务的控制。

DefaultTransactionDefinition是一个TransactionDefinition的实现类，是事务事务属性的定义和操作，而TransactionDefinition是事务基本属性的定义。

**org.springframework.jdbc.datasource.DriverManagerDataSource**

![DriverManagerDataSource](.\DriverManagerDataSource.png)

创建数据库连接且获取Connection

由关系图可见，DriverManagerDataSource的作用是Spring实现了一个获取数据库连接工具，其实现了javax.sql.DataSource。

AbstractDriverBasedDataSource：定义了数据库连接的数据字段。

AbstractDriverBasedDataSource和DriverManagerDataSource都具有获取数据连接Connection的方法，但最终都是通过DriverManager.getConnection方法获取数据连接。






