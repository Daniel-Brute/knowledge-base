
## 1 数据隔离级别分为不同的四种：

1）Serializable ：最严格的级别，事务串行执行，资源消耗最大；

2）REPEATABLE READ ：保证了一个事务不会修改已经由另一个事务读取但未提交（回滚）的数据。避免了“脏读取”和“不可重复读取”的情况，但是带来了更多的性能损失。

3）READ COMMITTED :大多数主流数据库的默认事务等级，保证了一个事务不会读到另一个并行事务已修改但未提交的数据，避免了“脏读取”。该级别适用于大多数系统。

4）Read Uncommitted ：保证了读取过程中不会读取到非法数据。

## 2 事务的传播级别：

1） PROPAGATION_REQUIRED：如果上下文中已经存在事务，那么就加入到事务中执行，如果当前上下文中不存在事务，则新建事务执行。默认的spring事务传播级别。所以这个级别通常能满足处理大多数的业务场景。

2）PROPAGATION_SUPPORTS：如果上下文存在事务，则支持事务加入事务，如果没有事务，则使用非事务的方式执行。所以说，并非所有的包在transactionTemplate.execute中的代码都会有事务支持。这个通常是用来处理那些并非原子性的非核心业务逻辑操作。应用场景较少。

3）PROPAGATION_MANDATORY：该级别的事务要求上下文中必须要存在事务，否则就会抛出异常！配置该方式的传播级别是有效的控制上下文调用代码遗漏添加事务控制的保证手段。比如一段代码不能单独被调用执行，但是一旦被调用，就必须有事务包含的情况，就可以使用这个传播级别。

4）PROPAGATION_REQUIRES_NEW：该传播级别的特点是，每次都会新建一个事务，并且同时将上下文中的事务挂起，执行当前新建事务完成以后，上下文事务恢复再执行。

> 这是一个很有用的传播级别，举一个应用场景：现在有一个发送100个红包的操作，在发送之前，要做一些系统的初始化、验证、数据记录操作，然后发送100封红包，然后再记录发送日志，发送日志要求100%的准确，如果日志不准确，那么整个父事务逻辑需要回滚。怎么处理整个业务需求呢？就是通过这个PROPAGATION_REQUIRES_NEW 级别的事务传播控制就可以完成。发送红包的子事务不会直接影响到父事务的提交和回滚。

5）PROPAGATION_NOT_SUPPORTED：当前级别的特点就是上下文中存在事务，则挂起事务，执行当前逻辑，结束后恢复上下文的事务。

> 这个级别有什么好处？可以帮助你将事务极可能的缩小。我们知道一个事务越大，它存在的风险也就越多。所以在处理事务的过程中，要保证尽可能的缩小范围。比如一段代码，是每次逻辑操作都必须调用的，比如循环1000次的某个非核心业务逻辑操作。这样的代码如果包在事务中，势必造成事务太大，导致出现一些难以考虑周全的异常情况。所以这个事务这个级别的传播级别就派上用场了。用当前级别的事务模板抱起来就可以了。

6）PROPAGATION_NEVER：该事务更严格，上面一个事务传播级别只是不支持而已，有事务就挂起，而PROPAGATION_NEVER传播级别要求上下文中不能存在事务，一旦有事务，就抛出runtime异常，强制停止执行！这个级别上辈子跟事务有仇。

7）PROPAGATION_NESTED：如果上下文中存在事务，则嵌套事务执行，如果不存在事务，则新建事务。

> 嵌套是子事务套在父事务中执行，子事务是父事务的一部分，在进入子事务之前，父事务建立一个回滚点，叫save point，然后执行子事务，这个子事务的执行也算是父事务的一部分，然后子事务执行结束，父事务继续执行。重点就在于那个save point。

> 如果子事务回滚，会发生什么？父事务会回滚到进入子事务前建立的save point，然后尝试其他的事务或者其他的业务逻辑，父事务之前的操作不会受到影响，更不会自动回滚。

> 如果父事务回滚，会发生什么？父事务回滚，子事务也会跟着回滚！为什么呢，因为父事务结束之前，子事务是不会提交的，我们说子事务是父事务的一部分，正是这个道理。那么：

> 事务的提交，是什么情况？是父事务先提交，然后子事务提交，还是子事务先提交，父事务再提交？答案是第二种情况，还是那句话，子事务是父事务的一部分，由父事务统一提交。

**一个逻辑操作需要检查的条件有20条，能否为了减小事务而将检查性的内容放到事务之外呢？**

> 对于核心的业务检查逻辑，不能放到事务之外，而且必须要作为分布式下的并发控制！一旦在事务之外做检查，那么势必会造成事务A已经检查过的数据被事务B所修改，导致事务A徒劳无功而且出现并发问题，直接导致业务控制失败。所以，在分布式的高并发环境下，对于核心业务逻辑的检查，要采用加锁机制。比如事务开启需要读取一条数据进行验证，然后逻辑操作中需要对这条数据进行修改，最后提交。这样的一个过程，如果读取并验证的代码放到事务之外，那么读取的数据极有可能已经被其他的事务修改，当前事务一旦提交，又会重新覆盖掉其他事务的数据，导致数据异常。所以在进入当前事务的时候，必须要将这条数据锁住，使用for update就是一个很好的在分布式环境下的控制手段。

> 一种好的实践方式是使用编程式事务而非生命式，尤其是在较为规模的项目中。对于事务的配置，在代码量非常大的情况下，将是一种折磨，而且人肉的方式，绝对不能避免这种问题。将DAO保持针对一张表的最基本操作，然后业务逻辑的处理放入manager和service中进行，同时使用编程式事务更精确的控制事务范围。特别注意的，对于事务内部一些可能抛出异常的情况，捕获要谨慎，不能随便的catch Exception 导致事务的异常被吃掉而不能正常回滚。

配置方式
```java
<!-- 配置SessionFactory -->
<bean id="sessionFactory" class="org.springframework.orm.hibernate3.LocalSessionFactoryBean">
    <property name="configLocation">
     <value>classpath:hibernate.cfg.xml</value>
    </property>
</bean>

<!-- 配置事务管理器 -->
<bean id="transactionManager" class="org.springframework.orm.hibernate3.HibernateTransactionManager">
    <property name="sessionFactory" ref="sessionFactory"/>
</bean>

<!-- 事务的传播特性 -->
<tx:advice id="txAdvice" transaction-manager="transactionManager">
    <tx:attributes>
     <tx:method name="add*" propagation="REQUIRED"/>
     <tx:method name="del*" propagation="REQUIRED"/>
     <tx:method name="modify*" propagation="REQUIRED"/>
     <tx:method name="*" propagation="REQUIRED" read-only="true"/>
    </tx:attributes>
</tx:advice>

<!-- 哪些类哪些方法使用事务 -->
<aop:config>
    <aop:pointcut expression="execution(* com.service.*.*(..))" id="transactionPC"/>
    <aop:advisor advice-ref="txAdvice" pointcut-ref="transactionPC"/>
</aop:config>

<!-- 普通IOC注入 -->
<bean id="userManager" class="com.service.UserManagerImpl">
    <property name="logManager" ref="logManager"/>
    <property name="sessionFactory" ref="sessionFactory"/>
</bean>
<bean id="logManager" class="com.service.LogManagerImpl">
    <property name="sessionFactory" ref="sessionFactory"/>
</bean>
```

## 3 声明式事务
实现机制
![](./pic/声明式事务实现机制.webp)

声明式事务管理有三种实现方式：基于TransactionProxyFactoryBean的方式、基于AspectJ的XML方式、基于注解的方式

注解事务的最基本是利用了spring的aop实现，调用者调用的实则是目标类的代理类，代理类有事务的拦截器Interceptor, TransactionInterceptor 来实现对应的事务处理

### 3.1.1 XML配置

```java
<!-- 事务化配置 -->
<tx:advice id="txAdvice" transaction-manager="txManager">
    <!-- 事务语义... -->
    <tx:attributes>
        <!-- 所有用'get'开头的方法都是只读的 -->
        <tx:method name="get*" read-only="true"/>
        <!-- 其他的方法使用默认的事务配置(看下面) -->
        <tx:method name="*"/>
    </tx:attributes>
</tx:advice>

<!-- 定义切面配置 -->
<aop:config>
    <!-- FooService 下的所有方法-->
    <aop:pointcut id="fooServiceOperation" expression="execution(* x.y.service.FooService.*(..))"/>
    <aop:advisor advice-ref="txAdvice" pointcut-ref="fooServiceOperation"/>
</aop:config>

<!-- DataSource数据源配置 -->
<bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource" destroy-method="close">
    <property name="driverClassName" value="oracle.jdbc.driver.OracleDriver"/>
    <property name="url" value="jdbc:oracle:thin:@rj-t42:1521:elvis"/>
    <property name="username" value="scott"/>
    <property name="password" value="tiger"/>
</bean>

<!-- 声明事务管理器实现 -->
<bean id="txManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
    <property name="dataSource" ref="dataSource"/>
</bean>
```

### 3.1.2 注解方式

```java
<!-- 数据源 -->
<bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource" destroy-method="close">
        <property name="driverClassName" value="oracle.jdbc.driver.OracleDriver"/>
        <property name="url" value="jdbc:oracle:thin:@rj-t42:1521:elvis"/>
        <property name="username" value="scott"/>
        <property name="password" value="tiger"/>
    </bean>
<!-- 使用注解配置的事务行为生效 -->
<tx:annotation-driven transaction-manager="txManager"/>

<!--事务管理器-->    
<bean id="txManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">        
        <property name="dataSource" ref="dataSource"/>
</bean>

<!--开启事务注解配置 -->
<tx:annotation-driven transaction-manager="txManager"/>
```

需要事务的方法加上注解即可
```java
//注解加到类上，则该类里所有public方法启用事务
//注解加在方法上，则只有方法启用事务
@Transactional
public class DefaultFooService implements FooService {

    Foo getFoo(String fooName);

    Foo getFoo(String fooName, String barName);

    void insertFoo(Foo foo);

    void updateFoo(Foo foo);
}
```
方法可见性和@Transactional
当使用代理时, 你应该只给public可见性的方法添加@Transactional注解. 如果你给protected, private或者包访问的方法添加了@Transactional注解, 不会产生错误, 但是事务不生效. 

**多数据源，多事务**

```java
<!-- 同上，不同的dataSource配置不同的txManager -->
<tx:annotation-driven transaction-manager="txManager"/>
<tx:annotation-driven transaction-manager="txManager1"/>
<tx:annotation-driven transaction-manager="txManager2"/>
```

```java
//名字和事务管理器同名即可
@Transactional("txManager1")
public class DefaultFooService implements FooService {

    Foo getFoo(String fooName);

    Foo getFoo(String fooName, String barName);

    void insertFoo(Foo foo);

    void updateFoo(Foo foo);
}
```

也可以给txManager加上别名

```java
<!--事务管理器-->    
<bean id="txManager1" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">        
      <qualifier value="order"/>
      <property name="dataSource" ref="dataSource"/>
    </bean>

<bean id="txManager2" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">        
      <qualifier value="account"/>
      <property name="dataSource" ref="dataSource"/>
    </bean>

<tx:annotation-driven transaction-manager="txManager1"/>
<tx:annotation-driven transaction-manager="txManager2"/>
```

```java
//名字和事务管理器的qualifier相同即可
@Transactional("order")
public class DefaultFooService implements FooService {

    Foo getFoo(String fooName);

    Foo getFoo(String fooName, String barName);

    void insertFoo(Foo foo);

    void updateFoo(Foo foo);
}
```
**使用注解的方式，注意下面这种情形，防止事务不生效**
1）不要对自己要进行事务控制的代码进行try catch，spring的事务触发是执行体出现异常，如果自己的程序catch住了异常，spring事务管理器以为执行成功，回滚不生效
```java
//错误示例
@Transactional
public void update2(String name){
    try {
        jdbcTemplate.execute("UPDATE t_menua SET  mname='"+name+"' WHERE mid=106 ");
    } catch (DataAccessException e) {
        e.printStackTrace();
    }
}

```

2）嵌套执行，A 调用 B ， A没有加事务注解，事务不生效

```java
//错误案例
@Transactional
public void update2(String name){
    jdbcTemplate.execute("UPDATE t_menua SET  mname='"+name+"' WHERE mid=106 ");
}

public void update3(String name) {
    this.update2(name);
    throw new RuntimeException();
}
```

```java
//事务生效
@Transactional
public void update2(String name){
    jdbcTemplate.execute("UPDATE t_menua SET  mname='"+name+"' WHERE mid=106 ");
}

@Transactional
public void update3(String name) {
    this.update2(name);
    throw new RuntimeException();
}
```

### 3.2 基于AspectJ的XML方式

在spring核心配置文件中添加事务管理器的配置、事务的增强以及切面

```java
    <!--配置事务管理器-->
    <bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
        <property name="dataSource" ref="dataSource" />
    </bean>

   <!--配置事务的通知-->
    <tx:advice id="txAdvice" transaction-manager="transactionManager">
        <tx:attributes>
            <tx:method name="transfer*" propagation="REQUIRED" />
        </tx:attributes>
    </tx:advice>

    <!--配置切面-->
    <aop:config>
        <aop:pointcut id="pointcut1" expression="execution(* com.tx.service.impl.*ServiceImpl.*(..))" />
        <aop:advisor advice-ref="txAdvice" pointcut-ref="pointcut1" />
    </aop:config>
```

测试代码：

```java
@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringTransactionApplicationTests {

    @Autowired
    TransferService transferService;

    @Test
    public void contextLoads() {
        transferService.transferMoney("Bill","Jack", 200L);
    }
}
```

### 3.3 基于TransactionProxyFactoryBean的方式
在spring核心配置文件中添加事务管理器的配置和TransactionProxyFactoryBean代理对象
```java
<!--配置事务管理器-->
<bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
    <property name="dataSource" ref="dataSource" />
</bean>

<!--配置业务层的代理-->
<bean id="transferServiceProxy" class="org.springframework.transaction.interceptor.TransactionProxyFactoryBean">
    <!--配置目标对象-->
    <property name="target" ref="transferService" />
    <!--注入事务管理器-->
    <property name="transactionManager" ref="transactionManager" />
    <!--注入事务属性-->
    <property name="transactionAttributes">
        <props>
        <!--prop的格式：
            * PROPAGATION :事务的传播行为
            * ISOLATION :事务的隔离级别
            * readOnly :是否只读
            * -Exception :发生哪些异常回滚事务
            * +Exception :发生哪些异常不回滚事务
        -->
            prop key="transfer*">PROPAGATION_REQUIRED</prop>
        </props>
    </property>
</bean>
```
测试代码：
```java
@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringTransactionApplicationTests {

    @Autowired
    TransferService transferService;

    @Resource(name="transferServiceProxy")
    TransferService transferServiceProxy;

    @Test
    public void contextLoads() {
        //注意，此处引入的是代理对象transferServiceProxy，而不是transferService
        transferServiceProxy.transferMoney("Bill","Jack", 200L);
    }
}
```

## 4 编程式事务

**通过TransactionTemplate手动管理事务，在实际应用中很少使用**

Spring配置
```java
<!-- dataSource 配置同上-->
<!-- 事务管理器 配置同上  管理器名字 txManage-->
<bean id="transactionTemplate" class="org.springframework.transaction.support.TransactionTemplate" >
    <property name="transactionManager" ref="txManage" />
</bean>
```


```java
public class LocalDataService {
    /**
     * 编程式事务模板
     */
    @Resource
    private TransactionTemplate transactionTemplate;
    /**
     * dao层执行体,可以是hibernate,mybatis等其它db框架
     */
    @Resource
    private JdbcTemplate jdbcTemplate;
    /**
     * 修改数据
     */
    public void update(final String name){

        transactionTemplate.execute(new TransactionCallback<Integer>() {
            public Integer doInTransaction(TransactionStatus transactionStatus) {
                jdbcTemplate.execute("UPDATE t_menua SET  mname='"+name+"' WHERE mid=106 ");
                return 1;
            }
        });

        throw new RuntimeException();
    }
}
```
transactionTemplate 官方有两种

TransactionTemplate
PlatformTransactionManager

Spring一般都推荐使用TransactionTemplate来进行编程式事务管理. 第二种方式有点类似于使用JTA的 UserTransaction接口
