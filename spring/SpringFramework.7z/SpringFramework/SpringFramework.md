
# 1 Spring概述

## Spring编程模型

面向对象编程

面向切面编程

面向元编程

函数驱动

模块驱动


## Spring 核心价值


# 2 Spring IoC

## Spring IoC依赖查找

根据Bean名称查找：实时查找、延时查找

根据Bean类型查找：单个bean对象、多个bean对象

根据注解查找：单个bean对象、多个bean对象

## Spring IoC依赖注入


根据Bean名称注入

根据Bean类型注入：单个bean对象、多个bean对象

注入容器内建Bean对象

注入非Bean对象

注入类型：实时注入、延时注入


## Spring IoC依赖的来源

自定义Bean

容器内建Bean对象

容器内建依赖

## IoC配置元信息

Bean定义配置

基于XML文件、基于Properties文件、基于JAVA注解、基于Java API

IoC容器配置

基于XML文件、基于JAVA注解、基于Java API

外部化属性配置

基于JAVA注解


## Spring IoC容器

BeanFactory与ApplicationContext的区别？


## Spring应用上下文

ApplicationContext除IoC容器之外，还包含了：面向切面、配置元信息、资源管理、事件、国际化、注解、Enviroment抽象

# 3 Spring Bean

## 定义 Spring Bean

什么是BeanDefinition?

BeanDefinition是SpringFramework中定义Bean的配置元信息接口，包括：Bean的名称、Bean行为配置元素（如作用域、自动绑定的模式、生命周期的回调等）、其它Bean引用（又可称作合作者或者依赖者）、配置设置（例如Bean属性）

**BeanDefinition元信息**

|属性|说明|
|--|--|
|Class|Bean全类名，必须是具体类，不能用抽象类或接口|
|Name|Bean的名称或者ID|
|Scope|Bean的作用域（如：singleton、prototype等）|
|Constructor arguments|Bean构造参数（用于依赖注入）|
|Properties|Bean属性设置（用于依赖注入）|
|Autowiring mode|Bean自动绑定模式（如通过名称byName）|
|Lazy initialization mode|Bean延迟初始化模式（延迟和非延迟）|
|Initialization method|Bean初始化回调方法名称|
|Destuction method|Bean销毁回调方法名称|

BeanDefinition构建

> 1）通过beanDefinitionBuilder

> 2）通过AbstractBeanDefinition以及派生类

```java
public class BeanDefinitionCreationDemo {

    public static void main(String[] args) {

        // 1.通过 BeanDefinitionBuilder 构建
        BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(User.class);
        // 通过属性设置
        beanDefinitionBuilder
                .addPropertyValue("id", 1)
                .addPropertyValue("name", "小马哥");
        // 获取 BeanDefinition 实例
        BeanDefinition beanDefinition = beanDefinitionBuilder.getBeanDefinition();
        // BeanDefinition 并非 Bean 终态，可以自定义修改

        // 2. 通过 AbstractBeanDefinition 以及派生类
        GenericBeanDefinition genericBeanDefinition = new GenericBeanDefinition();
        // 设置 Bean 类型
        genericBeanDefinition.setBeanClass(User.class);
        // 通过 MutablePropertyValues 批量操作属性
        MutablePropertyValues propertyValues = new MutablePropertyValues();
//        propertyValues.addPropertyValue("id", 1);
//        propertyValues.addPropertyValue("name", "小马哥");
        propertyValues
                .add("id", 1)
                .add("name", "小马哥");
        // 通过 set MutablePropertyValues 批量操作属性
        genericBeanDefinition.setPropertyValues(propertyValues);
    }
}
```

命名Spring Bean

每个Bean拥有一个或多个标识符，这些标识符在Bean所在的容器必须是唯一的，通常，一个bean仅有一个标识符，如果需要额外的，可以考虑使用别名扩展。

在基于XML的配置元信息中，开发人员可用id或者name属性来规定Bean的标识符。通常Bean的标识符由字母组成，允许出现特殊字符。如果想要引入Bean的别名的话，可在name户型使用半角逗号或者分号间隔。

Bean的id或name属性并非必须定制，如果留空的话，容器会为Bean自动生成一个唯一的名称。Bean的命名尽管没有限制，不过官方建议使用驼峰命名的方式，更符合Java的命名约定。


Bean名称生成器（BeanNameGenerator）
由Spring Famework2.0.3引入，框架内建两种实现：DefaultBeanNameGenerator（默认通过BeanNameGenerator实现）

AnnotationBeanNameGenerator：基于注解扫描的BeanNameGenerator，起始于Spring Framework 2.5
With component scanning in the classpath, Spring generates bean names for unnamed components, following the rules described earlier: essentially, taking the simple class name and turning its initial character to lower-case. However, in the (unusual) special case when there is more than one character and both the first and second characters are upper case, the original casing gets preserved. These are the same rules as defined by java.beans.Introspector.decapitalize (which Spring uses here).


Spring Bean的别名

Bean别名的价值：复用现有的BeanDefinition、更具有场景化的命名方法（如
```xml
<alias name= "myApp-dataSource" alias="subsystemA-DataSource"/>
```
）

```java
public class BeanAliasDemo {
    public static void main(String[] args) {
        // 配置 XML 配置文件
        // 启动 Spring 应用上下文
        BeanFactory beanFactory = new ClassPathXmlApplicationContext("classpath:/META-INF/bean-definitions-context.xml");
        // 通过别名 xiaomage-user 获取曾用名 user 的 bean
        User user = beanFactory.getBean("user", User.class);
        User xiaomageUser = beanFactory.getBean("xiaomage-user", User.class);
        System.out.println("xiaomage-user 是否与 user Bean 相同：" + (user == xiaomageUser));
    }
}
```

注册Spring Bean

BeanDefinition注册方式

XML配置元信息:<bean name="..." .../>

Java注解配置元信息：@Bean，@Component，@Import

java API配置元信息：

> 命名方式：BeanDefinitionRegistry#registryBeanDefinition(String, BeanDefinition)

> 非命名方式：BeanDefinitionReaderUtils#registerWithGeneratedName(AbstractBeanDefinition, BeanDefinitionRegister)

> 配置类方式：AnnotationBeanDefinitionReader#register(Class...)

```java
// 3. 通过 @Import 来进行导入
@Import(AnnotationBeanDefinitionDemo.Config.class)
public class AnnotationBeanDefinitionDemo {

    public static void main(String[] args) {
        // 创建 BeanFactory 容器
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext();
        // 注册 Configuration Class（配置类）
        applicationContext.register(AnnotationBeanDefinitionDemo.class);

        // 通过 BeanDefinition 注册 API 实现
        // 1.命名 Bean 的注册方式
        registerUserBeanDefinition(applicationContext, "mercyblitz-user");
        // 2. 非命名 Bean 的注册方法
        registerUserBeanDefinition(applicationContext);

        // 启动 Spring 应用上下文
        applicationContext.refresh();
        // 按照类型依赖查找
        System.out.println("Config 类型的所有 Beans" + applicationContext.getBeansOfType(Config.class));
        System.out.println("User 类型的所有 Beans" + applicationContext.getBeansOfType(User.class));
        // 显示地关闭 Spring 应用上下文
        applicationContext.close();
    }

    public static void registerUserBeanDefinition(BeanDefinitionRegistry registry, String beanName) {
        BeanDefinitionBuilder beanDefinitionBuilder = genericBeanDefinition(User.class);
        beanDefinitionBuilder
                .addPropertyValue("id", 1L)
                .addPropertyValue("name", "小马哥");

        // 判断如果 beanName 参数存在时
        if (StringUtils.hasText(beanName)) {
            // 注册 BeanDefinition
            registry.registerBeanDefinition(beanName, beanDefinitionBuilder.getBeanDefinition());
        } else {
            // 非命名 Bean 注册方法
            BeanDefinitionReaderUtils.registerWithGeneratedName(beanDefinitionBuilder.getBeanDefinition(), registry);
        }
    }

    public static void registerUserBeanDefinition(BeanDefinitionRegistry registry) {
        registerUserBeanDefinition(registry, null);
    }

    // 2. 通过 @Component 方式
    @Component // 定义当前类作为 Spring Bean（组件）
    public static class Config {

        // 1. 通过 @Bean 方式定义

        /**
         * 通过 Java 注解的方式，定义了一个 Bean
         */
        @Bean(name = {"user", "xiaomage-user"})
        public User user() {
            User user = new User();
            user.setId(1L);
            user.setName("小马哥");
            return user;
        }
    }


}

```

Bean实例化(instantiation)

常规方法：
```java
通过构造器（配置元信息：XML、java注解和Java API）
通过静态工厂方法（配置元信息：XML和Java API）
通过Bean工厂方法（配置元信息：XML和Java API）
通过FactoryBean（配置元信息：XML、java注解和Java API）

public class BeanInstantiationDemo {

    public static void main(String[] args) {
        // 配置 XML 配置文件
        // 启动 Spring 应用上下文
        BeanFactory beanFactory = new ClassPathXmlApplicationContext("classpath:/META-INF/bean-instantiation-context.xml");
        User user = beanFactory.getBean("user-by-static-method", User.class);
        User userByInstanceMethod = beanFactory.getBean("user-by-instance-method", User.class);
        User userByFactoryBean = beanFactory.getBean("user-by-factory-bean", User.class);
        System.out.println(user);
        System.out.println(userByInstanceMethod);
        System.out.println(userByFactoryBean);

        System.out.println(user == userByInstanceMethod);
        System.out.println(user == userByFactoryBean);

    }
}
```


特殊方法：
```java
通过ServiceLoaderFactoryBean（配置元信息：XML、java注解和Java API）
通过AutowireCapableBeanFactory#createBean(Class,int boolean)
通过BeanDefinitionRegistry#registerBeanDefinition(String, BeanDefinition)

public class SpecialBeanInstantiationDemo {

    public static void main(String[] args) {
        // 配置 XML 配置文件
        // 启动 Spring 应用上下文
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("classpath:/META-INF/special-bean-instantiation-context.xml");
        // 通过 ApplicationContext 获取 AutowireCapableBeanFactory
        AutowireCapableBeanFactory beanFactory = applicationContext.getAutowireCapableBeanFactory();

        ServiceLoader<UserFactory> serviceLoader = beanFactory.getBean("userFactoryServiceLoader", ServiceLoader.class);

        displayServiceLoader(serviceLoader);

//        demoServiceLoader();

        // 创建 UserFactory 对象，通过 AutowireCapableBeanFactory
        UserFactory userFactory = beanFactory.createBean(DefaultUserFactory.class);
        System.out.println(userFactory.createUser());

    }

    public static void demoServiceLoader() {
        ServiceLoader<UserFactory> serviceLoader = load(UserFactory.class, Thread.currentThread().getContextClassLoader());
        displayServiceLoader(serviceLoader);
    }

    private static void displayServiceLoader(ServiceLoader<UserFactory> serviceLoader) {
        Iterator<UserFactory> iterator = serviceLoader.iterator();
        while (iterator.hasNext()) {
            UserFactory userFactory = iterator.next();
            System.out.println(userFactory.createUser());
        }
    }
}
```

Bean初始化（Initialization）

- 1）@PostConstruct标注方法

- 2）实现Initializing接口的afterPropertiesSet()方法

- 3）自定义初始化方法：
 
 > XML配置：<bean init-method="init" .../>

 > Java注解：@Bean(initMethod="init")

 > Java API AbstractBeanDefinition#setInitMethodName(String)

装载顺序：1)->2)->3) 
```java
@Configuration // Configuration Class
public class BeanInitializationDemo {

    public static void main(String[] args) {
        // 创建 BeanFactory 容器
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext();
        // 注册 Configuration Class（配置类）
        applicationContext.register(BeanInitializationDemo.class);
        // 启动 Spring 应用上下文
        applicationContext.refresh();
        // 非延迟初始化在 Spring 应用上下文启动完成后，被初始化
        System.out.println("Spring 应用上下文已启动...");
        // 依赖查找 UserFactory
        UserFactory userFactory = applicationContext.getBean(UserFactory.class);
        System.out.println(userFactory);
        System.out.println("Spring 应用上下文准备关闭...");
        // 关闭 Spring 应用上下文
        applicationContext.close();
        System.out.println("Spring 应用上下文已关闭...");
    }

    @Bean(initMethod = "initUserFactory", destroyMethod = "doDestroy")
    @Lazy(value = false)
    public UserFactory userFactory() {
        return new DefaultUserFactory();
    }
}

public class DefaultUserFactory implements UserFactory, InitializingBean, DisposableBean {

    // 1. 基于 @PostConstruct 注解
    @PostConstruct
    public void init() {
        System.out.println("@PostConstruct : UserFactory 初始化中...");
    }

    public void initUserFactory() {
        System.out.println("自定义初始化方法 initUserFactory() : UserFactory 初始化中...");
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("InitializingBean#afterPropertiesSet() : UserFactory 初始化中...");
    }

    @PreDestroy
    public void preDestroy() {
        System.out.println("@PreDestroy : UserFactory 销毁中...");
    }

    @Override
    public void destroy() throws Exception {
        System.out.println("DisposableBean#destroy() : UserFactory 销毁中...");
    }

    public void doDestroy() {
        System.out.println("自定义销毁方法 doDestroy() : UserFactory 销毁中...");
    }

    @Override
    public void finalize() throws Throwable {
        System.out.println("当前 DefaultUserFactory 对象正在被垃圾回收...");
    }
}
```

Bean延迟初始化

> XML配置:<bean lazy-init="true" .../>

> Java注解：@lazy(true)

非延迟初始化在 Spring 应用上下文启动完成后，被初始化，上下文初始化之前加载

延迟初始化是按需初始化，上下文初始化之后加载

销毁Spring Bean

Bean销毁（Destroy）

@PreDestory
实现DisposableBean接口的destory()方法

自定义销毁方法

- 1）XML配置：<bean destroy="destory" .../>

- 2）Java注解：@Bean(destroy="destory")

- 3）Java API：AbstractBeanDefinition#setDestroyMethodName(String)

执行顺序：1）->2）->3）

垃圾回收Spring Bean

Bean垃圾回收(GC)

1）关闭Spring容器（应用上下文）

2）执行GC

3）Spring Bean覆盖finalize()方法被回调

```java
public class BeanGarbageCollectionDemo {

    public static void main(String[] args) throws InterruptedException {
        // 创建 BeanFactory 容器
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext();
        // 注册 Configuration Class（配置类）
        applicationContext.register(BeanInitializationDemo.class);
        // 启动 Spring 应用上下文
        applicationContext.refresh();
        // 关闭 Spring 应用上下文
        applicationContext.close();
        Thread.sleep(5000L);
        // 强制触发 GC
        System.gc();
        Thread.sleep(5000L);
    }

}
```



# Spring IoC 依赖查找

1）背景

单一类型依赖查询找

JNDI：javax.naming.Context#lookup(Name)
JavaBeans：java.beans.beancontext.BeanContext
集合类型查找：java.bean.beanContext.BeanContext

层次性依赖查找：java.beans.beanContext.BeanContext



层次性的查找

1）单一类型

1）集合类型

1）层次

1）延迟

1）安全

1）内建可查找的依赖

1）依赖查找中的异常



