Spring事务控制是由DataSourceTransactionManager做管理，但是事务的核心类是TransactionInterceptor的invoker方法执行业务的事务操作。



### 事务属性

Spring事务管理有三个核心的类

- 1）PlatformTransactionManager

PlatformTransactionManager是事务管理的抽象层，Spring根据这个抽象层提供许多不同的具体实现。比如`DataSourceTransactionManager、JpaTransactionManager、HibernateTransactionManager`等。如果想获取事务的操作，只需要使用PlatformTransactionManager接口即可。

- 2）TransactionDefinition

事务传播行为

| 序号 |         传播行为          | 值   |                             含义                             |
| :--: | :-----------------------: | ---- | :----------------------------------------------------------: |
|  1   |   PROPAGATION_REQUIRED    | 0    | 当前执行的方法必须在一个事务中执行，如果事务不存在则创建一个新的事务 |
|  2   |   PROPAGATION_SUPPORTS    | 1    | 当前执行的方法不需要事务上下文，但如果已经有一个事务在运行，则可以在事务中运行。 |
|  3   |   PROPAGATION_MANDATORY   | 2    |      当前方法必须在事务中执行，如果没有事务，则抛出异常      |
|  4   | PROPAGATION_REQUIRES_NEW  | 3    | 当前方法必须在事务中运行，则创建一个新的事务，如果已存在运行时的事务，则当前方法将备挂起。 |
|  5   | PROPAGATION_NOT_SUPPORTED | 4    |    当前方法不应在事务中执行，如果存在事务，挂起执行的方法    |
|  6   |     PROPAGATION_NEVER     | 5    |      当前方法不应在事务中执行，如果存在事务，则抛出异常      |
|  7   |    PROPAGATION_NESTED     | 6    | 如果当前方法在事务中执行，则创建一个新的事务执行；如果没有事务，则相当于PROPAGATION_REQUIRED |

事务隔离级别：

| 序号 | 隔离级别                   | 值   | 含义                       |
| ---- | -------------------------- | ---- | -------------------------- |
| 1    | ISOLATION_DEFAULT          | -1   | 基础数据存储的默认隔离级别 |
| 2    | ISOLATION_READ_UNCOMMITTED | 1    | 读未提交                   |
| 3    | ISOLATION_READ_COMMITTED   | 2    | 读已提交                   |
| 4    | ISOLATION_REPEATABLE_READ  | 4    | 可重复读                   |
| 5    | ISOLATION_SERIALIZABLE     | 8    | 序列化                     |



定义了事务级别和超时时间

```java
public interface TransactionDefinition {
    
    //事务的7个传播行为
    int PROPAGATION_REQUIRED = 0;
    int PROPAGATION_SUPPORTS = 1;
    int PROPAGATION_MANDATORY = 2;
    int PROPAGATION_REQUIRES_NEW = 3;
    int PROPAGATION_NOT_SUPPORTED = 4;
    int PROPAGATION_NEVER = 5;
    int PROPAGATION_NESTED = 6;

    //事务的5个隔离级别
    // 使用基础数据存储的默认隔离级别
    int ISOLATION_DEFAULT = -1;
    // Connection.TRANSACTION_READ_UNCOMMITTED;
    int ISOLATION_READ_UNCOMMITTED = 1;
    // Connection.TRANSACTION_READ_COMMITTED;
    int ISOLATION_READ_COMMITTED = 2;
    // Connection.TRANSACTION_REPEATABLE_READ
    int ISOLATION_REPEATABLE_READ = 4;
    // Connection.TRANSACTION_SERIALIZABLE
    int ISOLATION_SERIALIZABLE = 8;

    //事务超时时间
    int TIMEOUT_DEFAULT = -1;
    //返回传播行为
    int getPropagationBehavior();
    //返回隔离级别
    int getIsolationLevel();
    //返回超时时间
    int getTimeout();
    //是否为只读事务
    boolean isReadOnly();
    //返回事务的名称
    String getName();
}
```

- 3）TransactionStatus

![DefaultTransactionStatus](.\DefaultTransactionStatus.png)

DefaultTransactionStatus及其相关实现接口和抽象类中，保存了事务相关的参数和参数获取方法，包括：（、是否可读、新事务判断方法、

SavepointManager：创建、回滚到和释放保存点

TransactionStatus：是否有保存点

Flushable：刷新数据。

AbstractTransactionStatus：只读标识、完成标识、数据保存点。

DefaultTransactionStatus：是新事务对象、是否为新事务标识、是否为新的同步数据标识、制度标识、挂起事务对象



### 事务执行

使用方法如下

```xml
<!--启用事务事务管理的注解-->
<tx:annotation-driven/>

<!-- 或者使用标签 -->
<tx:advice id="txAdvice" transaction-manager="txManager" >   <!-- 仍然使用txManager作为事务管理组件 -->
    <tx:attributes>
        <!--事务管理方法列表-->
        <tx:method name="updateTitleAndBody" />   <!-- 在哪些方法上添加事务管理 -->
        <tx:method name="register" />             <!-- 这里写方法名 -->
        <tx:method name="checkLogin" />           <!-- 支持通配符 -->
        <tx:method name="listNotebook" />
        <tx:method name="getDeletedNotes" />
    </tx:attributes>
</tx:advice>

<!-- 指定需要进行事务增强的切面 -->
<aop:config>
	<aop:pointcut id="TxPointcut" expression="execution(* org.ssh.dao..*.*(..))"></aop:pointcut>
	<aop:advisor advice-ref="txAdvice" pointcut-ref="TxPointcut" ></aop:advisor>
</aop:config>
```



事务执行过程，可以通过tx标签的解析过程看一下Spring的事务是如何执行的

org.springframework.transaction.config.TxAdviceBeanDefinitionParser方法是做tx标签解析的

- 1、解析标签，获得事务含有事务属性的Bean

注册解析器：org.springframework.transaction.config.TxNamespaceHandler

BeanDefinition解析器：org.springframework.transaction.config.TxAdviceBeanDefinitionParser，将事务的bean转换成名称为TransactionInterceptor的Bean



![TxNamespaceHandler](.\TxNamespaceHandler.png)

```java
public class TxNamespaceHandler extends NamespaceHandlerSupport {

    // 事务管理器的引用标签
	static final String TRANSACTION_MANAGER_ATTRIBUTE = "transaction-manager";

    // 如果未定义标签，则使用默认的事务管理器的名称transactionManager
	static final String DEFAULT_TRANSACTION_MANAGER_BEAN_NAME = "transactionManager";

    // 获取事务管理器名称，用于事务属性解析时获取当前的事务管理器
	static String getTransactionManagerName(Element element) {
		return (element.hasAttribute(TRANSACTION_MANAGER_ATTRIBUTE) ?
				element.getAttribute(TRANSACTION_MANAGER_ATTRIBUTE) : DEFAULT_TRANSACTION_MANAGER_BEAN_NAME);
	}


	@Override
	public void init() {
         // 注册解析 <tx:advice/> 标签的类
		registerBeanDefinitionParser("advice", new TxAdviceBeanDefinitionParser());
        
        // 注册解析 <tx:annotation-driven/>标签的类
		registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
        
        // 注册解析<tx:jta-transaction-manager/>标签的方法，自动检测WebLogic和WebSphere服务器并公开相应的org.springframework.transaction.jta.JtaTransactionManager子类。
		registerBeanDefinitionParser("jta-transaction-manager", new JtaTransactionManagerBeanDefinitionParser());
	}

}

```

在TxNamespaceHandler的父类NamespaceHandlerSupport中有解析器的名称和对应的解析方法的容器，如下：

```java
/**
 * 保存解析器
 */
private final Map<String, BeanDefinitionParser> parsers = new HashMap<>();

/**
 * 保存装饰器
 */
private final Map<String, BeanDefinitionDecorator> decorators = new HashMap<>();

private final Map<String, BeanDefinitionDecorator> attributeDecorators = new HashMap<>();
```

在容器启动时，BeanDefinitionParserDelegate#parseCustomElement(Element ele)方法实现了NamespaceHandlerSupport的parse()方法的调用，进而获取到对应的BeanDefinition。

在NamespaceHandlerSupport的parse()方法中，首先获得了在TxNamespaceHandler中注册到parsers的TxAdviceBeanDefinitionParser，得到TxAdviceBeanDefinitionParser之后调用其解析Element元素的parse方法，获得包含了事务属性的BeanDefintion。

```java
public BeanDefinition parse(Element element, ParserContext parserContext) {
    // 获取Bean解析器
	BeanDefinitionParser parser = findParserForElement(element, parserContext);
	// 使用解析器，将element转换成BeanDefinition
    return (parser != null ? parser.parse(element, parserContext) : null);
}
```



2、事务拦截器执行事务控制

在上一步中可以看到，使用事务标签\<tx:XXX/>时，其实是将transactionManager作为一个属性封装到BeanDefinition中， 在这个时候事务的作用还是没有体现出来，需要在实际调用对象时，才会使用事务的相关操作。



org.springframework.transaction.interceptor.TransactionInterceptor

![TransactionInterceptor](.\TransactionInterceptor.png)



- MethodInterceptor

MethodInterceptor是Spring提供的在方法级别的拦截器接口，在使用时，需要实现invoke方法，传入的参数MethodInvocation中只包含了getMethod方法，以便于获取需要进行拦截的方法。

```java
public interface MethodInterceptor extends Interceptor {
   
   /**
    * Implement this method to perform extra treatments before and
    * after the invocation. Polite implementations would certainly
    * like to invoke {@link Joinpoint#proceed()}.
    * @param invocation the method invocation joinpoint
    * @return the result of the call to {@link Joinpoint#proceed()};
    * might be intercepted by the interceptor
    * @throws Throwable if the interceptors or the target object
    * throws an exception
    */
   Object invoke(MethodInvocation invocation) throws Throwable;

}
```



- TransactionAspectSupport

```java
	@Nullable
    protected Object invokeWithinTransaction(Method method, @Nullable Class<?> targetClass,
                                             final InvocationCallback invocation) throws Throwable {

        // If the transaction attribute is null, the method is non-transactional.
        TransactionAttributeSource tas = getTransactionAttributeSource();
        final TransactionAttribute txAttr = (tas != null ? tas.getTransactionAttribute(method, targetClass) : null);
        // // 根据事务的属性获取beanFactory中的PlatformTransactionManager(spring事务管理器的顶级接口)，一般这里或者的是DataSourceTransactiuonManager
        final TransactionManager tm = determineTransactionManager(txAttr);
        
        // 获取事务管理器
        PlatformTransactionManager ptm = asPlatformTransactionManager(tm);
        // 获取目标方法标识
        final String joinpointIdentification = methodIdentification(method, targetClass, txAttr);

        // CallbackPreferringPlatformTransactionManager集成了PlatformTransaction
        if (txAttr == null || !(ptm instanceof CallbackPreferringPlatformTransactionManager)) {
            // 组装事务相关的信息（事务管理器，事务状态，书屋的属性-传播方式，隔离级别等），并且与当前现成绑定
            TransactionInfo txInfo = createTransactionIfNecessary(ptm, txAttr, joinpointIdentification);

            Object retVal;
            try {
                // 执行业务代码，如果存在多个拦截器，则会进入下一个拦截器实现中
                retVal = invocation.proceedWithInvocation();
            } catch (Throwable ex) {
                // 回滚业务操作
                completeTransactionAfterThrowing(txInfo, ex);
                throw ex;
            } finally {
                // 在当前线程公开当前TransactionStatus，保留任何现有TransactionStatus，以便在此事务完成后还原。
                cleanupTransactionInfo(txInfo);
            }

            if (retVal != null && vavrPresent && VavrDelegate.isVavrTry(retVal)) {
                // 将当前对象的rollback-only设置为true
                TransactionStatus status = txInfo.getTransactionStatus();
                if (status != null && txAttr != null) {
                    retVal = VavrDelegate.evaluateTryFailure(retVal, txAttr, status);
                }
            }

            // 提交事务
            commitTransactionAfterReturning(txInfo);
            return retVal;
        }
        //  编程式事务处理，回调执行事务
        else {
            
            Object result;
            // 定义需要自定义的异常
            final ThrowableHolder throwableHolder = new ThrowableHolder();
           
            try {
                result = ((CallbackPreferringPlatformTransactionManager) ptm).execute(txAttr, status -> {
                    TransactionInfo txInfo = prepareTransactionInfo(ptm, txAttr, joinpointIdentification, status);
                    try {
                        // 执行业务逻辑
                        Object retVal = invocation.proceedWithInvocation();
                        if (retVal != null && vavrPresent && VavrDelegate.isVavrTry(retVal)) {
                            // Set rollback-only in case of Vavr failure matching our rollback rules...
                            retVal = VavrDelegate.evaluateTryFailure(retVal, txAttr, status);
                        }
                        return retVal;
                    } catch (Throwable ex) {
                        // 按照异常类型回滚数据
                        if (txAttr.rollbackOn(ex)) {
                            // A RuntimeException: will lead to a rollback.
                            if (ex instanceof RuntimeException) {
                                throw (RuntimeException) ex;
                            } else {
                                throw new ThrowableHolderException(ex);
                            }
                        } else {
                            // A normal return value: will lead to a commit.
                            throwableHolder.throwable = ex;
                            return null;
                        }
                    } finally {
                        cleanupTransactionInfo(txInfo);
                    }
                });
            } catch (ThrowableHolderException ex) {
                throw ex.getCause();
            } catch (TransactionSystemException ex2) {
                if (throwableHolder.throwable != null) {
                    logger.error("Application exception overridden by commit exception", throwableHolder.throwable);
                    ex2.initApplicationException(throwableHolder.throwable);
                }
                throw ex2;
            } catch (Throwable ex2) {
                if (throwableHolder.throwable != null) {
                    logger.error("Application exception overridden by commit exception", throwableHolder.throwable);
                }
                throw ex2;
            }

            // 检查自定义的异常信息，如果存在则抛出异常
            if (throwableHolder.throwable != null) {
                throw throwableHolder.throwable;
            }
            // 返回执行结果
            return result;
        }
    }
```

TransactionAspectSupport的内部类TransactionInfo是包含了事务的全部信息，如下所示。

```java
protected final class TransactionInfo {

    // 事务管理器
   private final PlatformTransactionManager transactionManager;

   private final TransactionAttribute transactionAttribute;

   private final String joinpointIdentification;

   private TransactionStatus transactionStatus;

   private TransactionInfo oldTransactionInfo;

   public TransactionInfo(PlatformTransactionManager transactionManager,
         TransactionAttribute transactionAttribute, String joinpointIdentification) {

      this.transactionManager = transactionManager;
      this.transactionAttribute = transactionAttribute;
      this.joinpointIdentification = joinpointIdentification;
   }

   public PlatformTransactionManager getTransactionManager() {
      return this.transactionManager;
   }

   public TransactionAttribute getTransactionAttribute() {
      return this.transactionAttribute;
   }

   /**
    * Return a String representation of this joinpoint (usually a Method call)
    * for use in logging.
    */
   public String getJoinpointIdentification() {
      return this.joinpointIdentification;
   }

   public void newTransactionStatus(TransactionStatus status) {
      this.transactionStatus = status;
   }

   public TransactionStatus getTransactionStatus() {
      return this.transactionStatus;
   }

   /**
    * Return whether a transaction was created by this aspect,
    * or whether we just have a placeholder to keep ThreadLocal stack integrity.
    */
   public boolean hasTransaction() {
      return (this.transactionStatus != null);
   }

   private void bindToThread() {
      // Expose current TransactionStatus, preserving any existing TransactionStatus
      // for restoration after this transaction is complete.
      this.oldTransactionInfo = transactionInfoHolder.get();
      transactionInfoHolder.set(this);
   }

   private void restoreThreadLocalStatus() {
      // Use stack to restore old transaction TransactionInfo.
      // Will be null if none was set.
      transactionInfoHolder.set(this.oldTransactionInfo);
   }

   @Override
   public String toString() {
      return this.transactionAttribute.toString();
   }
}
```

PlatformTransactionManager是事务管理器，当前的事务的所有操作都可以通过PlatformTransactionManager完成。PlatformTransactionManager是一个接口，其实在实际的执行时，使用的时spring-jdbc中的DataSourceTransactionManager完成数据库的操作。